from django.http import JsonResponse
from django.shortcuts import render

from prototype.models import Prototype


# Create your views here.


def savePrototype(request):
    if request.method == 'POST':
        animation = request.POST.get('animation')
        collapseName = request.POST.get('collapseName')
        component = request.POST.get('component')
        events = request.POST.get('events')
        groupStyle = request.POST.get('groupStyle')
        icon = request.POST.get('icon')
        id = request.POST.get('id')
        isLock = request.POST.get('isLock')
        label = request.POST.get('label')
        linkage = request.POST.get('linkage')
        propValue = request.POST.get('propValue')
        style = request.POST.get('style')

        try:
            prototype = Prototype(animation=animation, collapseName=collapseName,
                                  component=component, events=events,
                                  groupStyle=groupStyle, icon=icon,
                                  id=id, isLock=isLock, label=label,
                                  linkage=linkage, propValue=propValue, style=style)
            prototype.save()
            return JsonResponse({'errno': 0})
        except:
            return JsonResponse({'errno': 1002})

    else:
        return JsonResponse({'errno': 1001})


def getPrototype(request):
    if request.method == 'POST':
        id = request.POST.get('id')
        try:
            prototype = Prototype.objects.get(id=id)
            info = {
                'animations': prototype.animations,
                'collapseName': prototype.collapseName,
                'component': prototype.component,
                'events': prototype.events,
                'groupStyle': prototype.groupStyle,
                'icon': prototype.icon,
                'isLock': prototype.isLock,
                'label': prototype.label,
                'linkage': prototype.linkage,
                'propValue': prototype.propValue,
                'style': prototype.style
            }
            return JsonResponse({'errno': 0, 'info': info})
        except:
            return JsonResponse({'errno': 1002})

    else:
        return JsonResponse({'errno': 1001})
















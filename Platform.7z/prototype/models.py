from django.db import models

# Create your models here.


class Prototype(models.Model):
    id = models.AutoField(primary_key=True)
    animations = models.CharField(max_length=4096)
    collapseName = models.CharField(max_length=64)
    component = models.CharField(max_length=64)
    events = models.CharField(max_length=4096)
    groupStyle = models.CharField(max_length=4096)
    icon = models.CharField(max_length=64)
    isLock = models.BooleanField(default=False)
    label = models.CharField(max_length=64)
    linkage = models.CharField(max_length=4096)
    propValue = models.CharField(max_length=64)
    style = models.CharField(max_length=4096)


    class Meta:
        db_table = 'prototype'













